# `kill-switch-ufw`

> bloque, au moyen de règles de pare-feu, les connexions Internet directes via
> les interfaces de liaison montante physiques en dehors du tunnel VPN.

---

> Cela nécessite un tunnel VPN déjà établi avec sa propre
> interface. Si la connexion est changée ou rétablie, il peut être nécessaire
> de désactiver brièvement le kill switch afin de réinitialiser la connexion VPN.
>
> C’est le cas si le point de terminaison change lors d’une reconnexion ou d’un
> changement de connexion.

---

> Les options de commande fonctionnent comme des interrupteurs : ce qui est
> désactivé est activé – et inversement.

---

### `-h|--help`

> affiche cette page d’aide

### `-s|--status`

> affiche l’état actuel du kill switch

### `-a|--standard`

> permet de faire passer une seule interface en mode standard
>
> `-a|--standard [nom de l’interface]`

### `-b|--paranoid`

> permet de faire passer une seule interface en mode paranoïaque
>
> Ce mode bloque également les adresses privées en dehors du tunnel VPN
>
> `-b|--paranoid [nom de l’interface]`

### `-e|--eth`

> active ou désactive le kill switch ETHERNET
>
> Les adresses locales restent accessibles en dehors du VPN

### `-w|--wlan`

> active ou désactive le kill switch WLAN
>
> Les adresses locales restent accessibles en dehors du VPN

### `-v|--wwan`

> active ou désactive le kill switch WWAN
>
> Les adresses locales restent accessibles en dehors du VPN

### `-p|--paranoid-eth`

> fonctionne comme -e|--eth
>
> OUTPUT via ETHERNET uniquement par l’interface VPN

### `-q|--paranoid-wlan`

> fonctionne comme -w|--wlan
>
> OUTPUT via WLAN uniquement par l’interface VPN

### `-x|--paranoid-wwan`

> fonctionne comme -v|--wwan
>
> OUTPUT via WWAN uniquement par l’interface VPN

### `-y|--reboot-onoff`

> détermine si le kill switch reste activé ou est désactivé après un redémarrage
>
> Cette option doit être configurée pendant l’installation

### `-r|--rules`

> affiche les règles UFW définies par cette application

### `-z|--delete-rules`

> Désactive le kill switch pour toutes les interfaces (quiet)

---

## Remarques

- Les options -e & -p s’annulent mutuellement
- Les options -w & -q s’annulent mutuellement
- Les options -v & -x s’annulent mutuellement
- Les requêtes DNS locales adressées au routeur sont bloquées dans tous les modes
  (protection contre les fuites DNS)

## Avertissements

- Gardez votre pare-feu UFW activé en permanence.
- `kill-switch-ufw` active le pare-feu UFW à chaque exécution.
- `kill-switch-ufw` ne peut pas réagir à un pare-feu désactivé tant qu’il n’est
  pas exécuté.

## Exemples

> `kill-switch-ufw -e`
>
> Active le kill switch uniquement pour les connexions ETHERNET. Les adresses
> locales restent accessibles

> `kill-switch-ufw -e -w -v`
>
> Active le kill switch pour TOUTES les connexions. Les adresses locales restent
> accessibles

> `kill-switch-ufw -p -q -x`
>
> Active le kill switch pour TOUTES les connexions. Les adresses locales ne sont
> alors accessibles que par le tunnel VPN.

> `kill-switch-ufw -z -v`
>
> Désactive le kill switch sur toutes les interfaces réseau, puis l’active
> uniquement pour le WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Active le kill switch sur toutes les interfaces ETHERNET sauf `eth2`.
