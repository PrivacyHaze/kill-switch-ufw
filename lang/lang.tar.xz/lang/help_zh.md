# `kill-switch-ufw`

> 通过防火墙规则阻止经由物理上行接口绕过 VPN 隧道的
> 直接互联网连接。

---

> 此功能要求已经建立一个具有独立接口的 VPN 隧道。
> 更换连接或重新建立连接时，可能需要暂时禁用 Kill Switch，
> 以便重新初始化 VPN 连接。
>
> 如果端点在重新连接或切换连接时发生变化，就会出现这种情况。

---

> 控制选项的作用类似于开关：禁用的设置会被启用，反之亦然。

---

### `-h|--help`

> 显示此帮助页面

### `-s|--status`

> 显示当前 Kill Switch 状态

### `-a|--standard`

> 允许将单个接口切换到标准模式
>
> `-a|--standard [接口名称]`

### `-b|--paranoid`

> 允许将单个接口切换到严格模式
>
> 此模式还会阻止访问 VPN 隧道之外的私有地址
>
> `-b|--paranoid [接口名称]`

### `-e|--eth`

> 开启或关闭 ETHERNET Kill Switch
>
> 本地地址在 VPN 之外仍可访问

### `-w|--wlan`

> 开启或关闭 WLAN Kill Switch
>
> 本地地址在 VPN 之外仍可访问

### `-v|--wwan`

> 开启或关闭 WWAN Kill Switch
>
> 本地地址在 VPN 之外仍可访问

### `-p|--paranoid-eth`

> 功能类似于 -e|--eth
>
> 经由 ETHERNET 的 OUTPUT 只能通过 VPN 接口

### `-q|--paranoid-wlan`

> 功能类似于 -w|--wlan
>
> 经由 WLAN 的 OUTPUT 只能通过 VPN 接口

### `-x|--paranoid-wwan`

> 功能类似于 -v|--wwan
>
> 经由 WWAN 的 OUTPUT 只能通过 VPN 接口

### `-y|--reboot-onoff`

> 控制 Kill Switch 在重启后保持启用还是被禁用
>
> 此选项必须在安装期间配置

### `-r|--rules`

> 显示此应用程序设置的 UFW 规则

### `-z|--delete-rules`

> 为所有接口禁用 Kill Switch（quiet）

---

## 注意事项：

- 选项 -e 与 -p 会相互抵消
- 选项 -w 与 -q 会相互抵消
- 选项 -v 与 -x 会相互抵消
- 所有模式都会阻止发送到路由器的本地 DNS 查询
  （DNS 泄漏防护）

## 警告：

- 请始终保持 UFW 防火墙处于启用状态。
- 每次运行 `kill-switch-ufw` 时，它都会启用 UFW 防火墙。
- 未运行 `kill-switch-ufw` 时，它无法对被禁用的防火墙作出响应。

## 示例：

> `kill-switch-ufw -e`
>
> 仅为 ETHERNET 连接启用 Kill Switch。本地地址
> 仍可访问

> `kill-switch-ufw -e -w -v`
>
> 为所有连接启用 Kill Switch。本地地址
> 仍可访问

> `kill-switch-ufw -p -q -x`
>
> 为所有连接启用 Kill Switch。本地地址只能
> 通过 VPN 隧道访问。

> `kill-switch-ufw -z -v`
>
> 为所有网络接口禁用 Kill Switch，然后仅为 WWAN 启用它。

> `kill-switch-ufw -e -a eth2`
>
> 为除 `eth2` 之外的所有 ETHERNET 接口启用 Kill Switch。
