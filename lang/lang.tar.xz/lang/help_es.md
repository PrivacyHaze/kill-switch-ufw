# `kill-switch-ufw`

> bloquea mediante reglas de cortafuegos las conexiones directas a Internet
> a través de las interfaces físicas de enlace ascendente fuera del túnel VPN.

---

> Esto requiere un túnel VPN ya establecido con su propia
> interfaz. Si se cambia o se vuelve a establecer la conexión, puede ser necesario
> desactivar brevemente el kill switch para reinicializar la conexión VPN.
>
> Esto ocurre si el endpoint cambia durante una reconexión o un cambio de conexión.

---

> Las opciones de control funcionan como interruptores: lo que está desactivado
> se activa, y viceversa.

---

### `-h|--help`

> muestra esta página de ayuda

### `-s|--status`

> muestra el estado actual del kill switch

### `-a|--standard`

> permite cambiar una sola interfaz al modo estándar
>
> `-a|--standard [nombre de la interfaz]`

### `-b|--paranoid`

> permite cambiar una sola interfaz al modo paranoico
>
> Este modo también bloquea las direcciones privadas fuera del túnel VPN
>
> `-b|--paranoid [nombre de la interfaz]`

### `-e|--eth`

> activa o desactiva el kill switch de ETHERNET
>
> Las direcciones locales siguen siendo accesibles fuera de la VPN

### `-w|--wlan`

> activa o desactiva el kill switch de WLAN
>
> Las direcciones locales siguen siendo accesibles fuera de la VPN

### `-v|--wwan`

> activa o desactiva el kill switch de WWAN
>
> Las direcciones locales siguen siendo accesibles fuera de la VPN

### `-p|--paranoid-eth`

> funciona como -e|--eth
>
> OUTPUT por ETHERNET únicamente a través de la interfaz VPN

### `-q|--paranoid-wlan`

> funciona como -w|--wlan
>
> OUTPUT por WLAN únicamente a través de la interfaz VPN

### `-x|--paranoid-wwan`

> funciona como -v|--wwan
>
> OUTPUT por WWAN únicamente a través de la interfaz VPN

### `-y|--reboot-onoff`

> controla si el kill switch permanece activado o se desactiva después de reiniciar
>
> Esta opción debe configurarse durante la instalación

### `-r|--rules`

> muestra las reglas de UFW establecidas por esta aplicación

### `-z|--delete-rules`

> desactiva el kill switch para todas las interfaces (quiet)

---

## Notas

- Las opciones -e & -p se anulan mutuamente
- Las opciones -w & -q se anulan mutuamente
- Las opciones -v & -x se anulan mutuamente
- Las consultas DNS locales al rúter se bloquean en todos los modos
  (protección contra fugas de DNS)

## Advertencias

- Mantén siempre activado el cortafuegos UFW.
- `kill-switch-ufw` activa el cortafuegos UFW cada vez que se ejecuta.
- `kill-switch-ufw` no puede reaccionar ante un cortafuegos desactivado mientras
  no se ejecute.

## Ejemplos

> `kill-switch-ufw -e`
>
> Activa el kill switch únicamente para las conexiones ETHERNET. Las direcciones
> locales siguen siendo accesibles

> `kill-switch-ufw -e -w -v`
>
> Activa el kill switch para TODAS las conexiones. Las direcciones locales siguen
> siendo accesibles

> `kill-switch-ufw -p -q -x`
>
> Activa el kill switch para TODAS las conexiones. Las direcciones locales solo
> son accesibles a través del túnel VPN.

> `kill-switch-ufw -z -v`
>
> Desactiva el kill switch en todas las interfaces de red y, a continuación,
> lo activa únicamente para WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Activa el kill switch en todas las interfaces ETHERNET excepto `eth2`.
