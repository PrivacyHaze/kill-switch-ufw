# `kill-switch-ufw`

> blokuje za pomocą reguł zapory bezpośrednie połączenia internetowe przez
> fizyczne interfejsy uplink poza tunelem VPN.

---

> Wymaga to wcześniej zestawionego tunelu VPN z własnym
> interfejsem. Jeśli połączenie zostanie zmienione lub zestawione ponownie, może być
> konieczne krótkotrwałe wyłączenie mechanizmu kill switch w celu ponownej inicjalizacji
> połączenia VPN.
>
> Dzieje się tak, gdy endpoint zmieni się podczas ponownego łączenia lub zmiany połączenia.

---

> Opcje sterujące działają jak przełączniki: ustawienie wyłączone zostaje
> włączone — i odwrotnie.

---

### `-h|--help`

> wyświetla tę stronę pomocy

### `-s|--status`

> wyświetla bieżący stan mechanizmu kill switch

### `-a|--standard`

> umożliwia przełączenie pojedynczego interfejsu w tryb standardowy
>
> `-a|--standard [nazwa interfejsu]`

### `-b|--paranoid`

> umożliwia przełączenie pojedynczego interfejsu w tryb paranoiczny
>
> Ten tryb blokuje również adresy prywatne poza tunelem VPN
>
> `-b|--paranoid [nazwa interfejsu]`

### `-e|--eth`

> włącza lub wyłącza mechanizm kill switch dla ETHERNET
>
> Adresy lokalne pozostają osiągalne poza VPN

### `-w|--wlan`

> włącza lub wyłącza mechanizm kill switch dla WLAN
>
> Adresy lokalne pozostają osiągalne poza VPN

### `-v|--wwan`

> włącza lub wyłącza mechanizm kill switch dla WWAN
>
> Adresy lokalne pozostają osiągalne poza VPN

### `-p|--paranoid-eth`

> działa tak samo jak -e|--eth
>
> OUTPUT przez ETHERNET wyłącznie przez interfejs VPN

### `-q|--paranoid-wlan`

> działa tak samo jak -w|--wlan
>
> OUTPUT przez WLAN wyłącznie przez interfejs VPN

### `-x|--paranoid-wwan`

> działa tak samo jak -v|--wwan
>
> OUTPUT przez WWAN wyłącznie przez interfejs VPN

### `-y|--reboot-onoff`

> określa, czy po ponownym uruchomieniu mechanizm kill switch pozostaje włączony, czy zostaje wyłączony
>
> Tę opcję należy skonfigurować podczas instalacji

### `-r|--rules`

> wyświetla reguły UFW ustawione przez tę aplikację

### `-z|--delete-rules`

> wyłącza mechanizm kill switch dla wszystkich interfejsów (quiet)

---

## Uwagi

- Opcje -e & -p wzajemnie się znoszą
- Opcje -w & -q wzajemnie się znoszą
- Opcje -v & -x wzajemnie się znoszą
- Lokalne zapytania DNS do routera są blokowane we wszystkich trybach
  (ochrona przed wyciekiem DNS)

## Ostrzeżenia

- Utrzymuj zaporę UFW stale włączoną.
- `kill-switch-ufw` włącza zaporę UFW przy każdym uruchomieniu.
- `kill-switch-ufw` nie może zareagować na wyłączoną zaporę, dopóki nie zostanie uruchomiony.

## Przykłady

> `kill-switch-ufw -e`
>
> Włącza mechanizm kill switch tylko dla połączeń ETHERNET. Adresy lokalne
> pozostają osiągalne

> `kill-switch-ufw -e -w -v`
>
> Włącza mechanizm kill switch dla WSZYSTKICH połączeń. Adresy lokalne pozostają
> osiągalne

> `kill-switch-ufw -p -q -x`
>
> Włącza mechanizm kill switch dla WSZYSTKICH połączeń. Adresy lokalne są wtedy
> osiągalne tylko przez tunel VPN.

> `kill-switch-ufw -z -v`
>
> Wyłącza mechanizm kill switch dla wszystkich interfejsów sieciowych,
> a następnie włącza go wyłącznie dla WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Włącza mechanizm kill switch dla wszystkich interfejsów ETHERNET z wyjątkiem `eth2`.
