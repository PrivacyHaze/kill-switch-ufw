# `kill-switch-ufw`

> blockiert direkte Internetverbindungen über die physischen
> Uplink-Schnittstellen außerhalb des VPN-Tunnels durch Firewall-Regeln.

---

> Dies setzt einen bereits aufgebauten VPN-Tunnel mit eigener
> Schnittstelle voraus. Wird die Verbindung gewechselt oder neu aufgebaut,
> kann es notwendig sein, den Kill Switch für eine erneute Initialisierung
> der VPN-Verbindung kurzzeitig zu deaktivieren.
>
> Dies ist der Fall, wenn sich der VPN-Endpunkt bei einem erneuten
> Verbindungsaufbau oder einem Verbindungswechsel ändert.

---

> Die Steuerungsoptionen fungieren als Umschalter: Was deaktiviert ist, wird
> aktiviert – und umgekehrt.

---

### `-h|--help`

> zeigt diese Hilfeseite

### `-s|--status`

> zeigt den aktuellen Kill-Switch-Status

### `-a|--standard`

> ermöglicht das Umschalten einer einzelnen Schnittstelle in den Standardmodus
>
> `-a|--standard [Name der Schnittstelle]`

### `-b|--paranoid`

> ermöglicht das Umschalten einer einzelnen Schnittstelle in den Paranoidmodus
>
> Dieser Modus blockiert auch private Adressen außerhalb des VPN-Tunnels
>
> `-b|--paranoid [Name der Schnittstelle]`

### `-e|--eth`

> Umschalter für den ETHERNET-Kill-Switch (an/aus)
>
> Lokale Adressen bleiben außerhalb des VPN-Tunnels erreichbar

### `-w|--wlan`

> Umschalter für den WLAN-Kill-Switch (an/aus)
>
> Lokale Adressen bleiben außerhalb des VPN-Tunnels erreichbar

### `-v|--wwan`

> Umschalter für den WWAN-Kill-Switch (an/aus)
>
> Lokale Adressen bleiben außerhalb des VPN-Tunnels erreichbar

### `-p|--paranoid-eth`

> vergleichbar mit -e|--eth
>
> OUTPUT via ETHERNET nur noch über das VPN-Interface

### `-q|--paranoid-wlan`

> vergleichbar mit -w|--wlan
>
> OUTPUT via WLAN nur noch über das VPN-Interface

### `-x|--paranoid-wwan`

> vergleichbar mit -v|--wwan
>
> OUTPUT via WWAN nur noch über das VPN-Interface

### `-y|--reboot-onoff`

> steuert, ob der Kill Switch nach einem Neustart aktiviert bleibt oder deaktiviert wird
>
> Diese Option muss während der Installation eingerichtet werden

### `-r|--rules`

> zeigt die von dieser Anwendung gesetzten UFW-Regeln

### `-z|--delete-rules`

> deaktiviert den Kill Switch für alle Schnittstellen (quiet)

---

## Hinweise

- Die Optionen -e & -p heben einander auf
- Die Optionen -w & -q heben einander auf
- Die Optionen -v & -x heben einander auf
- **Lokale DNS-Anfragen zum Router werden in allen Modi gesperrt
  (DNS-Leak-Schutz)**

## Warnhinweise

- Halte deine UFW-Firewall stets aktiviert.
- `kill-switch-ufw` aktiviert die UFW-Firewall mit jedem Aufruf.
- Die Anwendung kann nicht auf eine ausgeschaltete Firewall reagieren,
  solange sie nicht aufgerufen wird.

## Beispiele

> `kill-switch-ufw -e`
>
> Aktiviert den Kill Switch nur für ETHERNET-Verbindungen. Lokale Adressen
> bleiben erreichbar.

> `kill-switch-ufw -e -w -v`
>
> Aktiviert den Kill Switch für ALLE Verbindungen. Lokale Adressen bleiben
> erreichbar.

> `kill-switch-ufw -p -q -x`
>
> Aktiviert den Kill Switch für ALLE Verbindungen. Lokale Adressen sind nur noch
> über den VPN-Tunnel erreichbar.

> `kill-switch-ufw -z -v`
>
> Deaktiviert den Kill Switch für alle Netzwerkschnittstellen und aktiviert ihn
> anschließend nur für WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Aktiviert den Kill Switch für alle ETHERNET-Schnittstellen mit Ausnahme von `eth2`.
