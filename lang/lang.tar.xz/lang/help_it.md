# `kill-switch-ufw`

> blocca tramite regole firewall le connessioni Internet dirette attraverso
> le interfacce uplink fisiche al di fuori del tunnel VPN.

---

> Ciò richiede un tunnel VPN già stabilito e dotato di una propria
> interfaccia. Se la connessione viene cambiata o ristabilita, potrebbe essere
> necessario disattivare brevemente il kill switch per reinizializzare la connessione VPN.
>
> Questo accade se l’endpoint cambia durante una riconnessione o un cambio di connessione.

---

> Le opzioni di controllo funzionano come interruttori: ciò che è disattivato
> viene attivato, e viceversa.

---

### `-h|--help`

> mostra questa pagina di aiuto

### `-s|--status`

> mostra lo stato attuale del kill switch

### `-a|--standard`

> consente di impostare una singola interfaccia in modalità standard
>
> `-a|--standard [nome dell’interfaccia]`

### `-b|--paranoid`

> consente di impostare una singola interfaccia in modalità paranoica
>
> Questa modalità blocca anche gli indirizzi privati al di fuori del tunnel VPN
>
> `-b|--paranoid [nome dell’interfaccia]`

### `-e|--eth`

> attiva o disattiva il kill switch ETHERNET
>
> Gli indirizzi locali restano raggiungibili al di fuori della VPN

### `-w|--wlan`

> attiva o disattiva il kill switch WLAN
>
> Gli indirizzi locali restano raggiungibili al di fuori della VPN

### `-v|--wwan`

> attiva o disattiva il kill switch WWAN
>
> Gli indirizzi locali restano raggiungibili al di fuori della VPN

### `-p|--paranoid-eth`

> funziona come -e|--eth
>
> OUTPUT via ETHERNET esclusivamente tramite l’interfaccia VPN

### `-q|--paranoid-wlan`

> funziona come -w|--wlan
>
> OUTPUT via WLAN esclusivamente tramite l’interfaccia VPN

### `-x|--paranoid-wwan`

> funziona come -v|--wwan
>
> OUTPUT via WWAN esclusivamente tramite l’interfaccia VPN

### `-y|--reboot-onoff`

> stabilisce se il kill switch resta attivo o viene disattivato dopo un riavvio
>
> Questa opzione deve essere configurata durante l’installazione

### `-r|--rules`

> mostra le regole UFW impostate da questa applicazione

### `-z|--delete-rules`

> disattiva il kill switch per tutte le interfacce (quiet)

---

## Note

- Le opzioni -e & -p si annullano a vicenda
- Le opzioni -w & -q si annullano a vicenda
- Le opzioni -v & -x si annullano a vicenda
- Le richieste DNS locali al router vengono bloccate in tutte le modalità
  (protezione contro le perdite DNS)

## Avvertenze

- Mantieni sempre attivo il firewall UFW.
- `kill-switch-ufw` attiva il firewall UFW a ogni esecuzione.
- `kill-switch-ufw` non può reagire a un firewall disattivato finché non viene eseguito.

## Esempi

> `kill-switch-ufw -e`
>
> Attiva il kill switch solo per le connessioni ETHERNET. Gli indirizzi locali
> restano raggiungibili

> `kill-switch-ufw -e -w -v`
>
> Attiva il kill switch per TUTTE le connessioni. Gli indirizzi locali restano
> raggiungibili

> `kill-switch-ufw -p -q -x`
>
> Attiva il kill switch per TUTTE le connessioni. Gli indirizzi locali sono
> raggiungibili solo tramite il tunnel VPN.

> `kill-switch-ufw -z -v`
>
> Disattiva il kill switch per tutte le interfacce di rete e successivamente
> lo attiva solo per WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Attiva il kill switch per tutte le interfacce ETHERNET tranne `eth2`.
