# `kill-switch-ufw`

> blocks direct Internet connections via the physical uplink
> interfaces outside the VPN tunnel using firewall rules.

---

> This requires an already established VPN tunnel with its own
> interface. If the connection is changed or re-established, it may be necessary
> to disable the kill switch briefly so the VPN connection can be initialized again.
>
> This is the case if the endpoint changes during a reconnect or connection switch.

---

> The control options act as toggles: A disabled setting is enabled – and vice versa.

---

### `-h|--help`

> shows this help page

### `-s|--status`

> shows the current kill switch status

### `-a|--standard`

> allows a single interface to be switched to standard mode
>
> `-a|--standard [interface name]`

### `-b|--paranoid`

> allows a single interface to be switched to paranoid mode
>
> This mode also blocks private addresses outside the VPN tunnel
>
> `-b|--paranoid [interface name]`

### `-e|--eth`

> toggles the ETHERNET kill switch (on/off)
>
> Local addresses remain reachable outside the VPN

### `-w|--wlan`

> toggles the WLAN kill switch (on/off)
>
> Local addresses remain reachable outside the VPN

### `-v|--wwan`

> toggles the WWAN kill switch (on/off)
>
> Local addresses remain reachable outside the VPN

### `-p|--paranoid-eth`

> works like -e|--eth
>
> OUTPUT via ETHERNET only through the VPN interface

### `-q|--paranoid-wlan`

> works like -w|--wlan
>
> OUTPUT via WLAN only through the VPN interface

### `-x|--paranoid-wwan`

> works like -v|--wwan
>
> OUTPUT via WWAN only through the VPN interface

### `-y|--reboot-onoff`

> controls whether the kill switch remains enabled or is disabled after a reboot
>
> This option must be configured during installation

### `-r|--rules`

> shows the UFW rules set by this application

### `-z|--delete-rules`

> Disables the kill switch for all interfaces (quiet)

---

## Notes

- The options -e & -p cancel each other out
- The options -w & -q cancel each other out
- The options -v & -x cancel each other out
- Local DNS queries to the router are blocked in all modes
  (DNS leak protection)

## Warnings

- Keep your UFW firewall enabled at all times.
- `kill-switch-ufw` enables the UFW firewall each time it is run.
- `kill-switch-ufw` cannot respond to a disabled firewall while it is not running.

## Examples

> `kill-switch-ufw -e`
>
> Enables the kill switch only for ETHERNET connections. Local addresses
> remain reachable

> `kill-switch-ufw -e -w -v`
>
> Enables the kill switch for ALL connections. Local addresses remain
> reachable

> `kill-switch-ufw -p -q -x`
>
> Enables the kill switch for ALL connections. Local addresses are then only
> reachable through the VPN tunnel.

> `kill-switch-ufw -z -v`
>
> Disables the kill switch for all network interfaces and then enables it only
> for WWAN.

> `kill-switch-ufw -e -a eth2`
>
> Enables the kill switch for all ETHERNET interfaces except `eth2`.
